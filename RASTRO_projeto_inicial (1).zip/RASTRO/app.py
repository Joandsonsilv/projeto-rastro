import streamlit as st
from modules.dados import carregar_bases
from modules.componentes import aplicar_estilo, cabecalho, menu_lateral
from modules.filtros import tela_consulta
from modules.indicadores import tela_dashboard, tela_pendencias, tela_base_dados
from modules.validacoes import tela_validacoes

st.set_page_config(page_title="RASTRO | Rastreamento de Ativos", page_icon="🔎", layout="wide")
aplicar_estilo()

df, avisos = carregar_bases()
for aviso in avisos:
    st.warning(aviso)

cabecalho()
pagina = menu_lateral()

if df.empty:
    st.error("Nenhuma base foi carregada. Verifique os arquivos da pasta data.")
    st.stop()

if pagina == "Consulta":
    tela_consulta(df)
elif pagina == "Dashboard":
    tela_dashboard(df)
elif pagina == "Painel de Pendências":
    tela_pendencias(df)
elif pagina == "Base de Dados":
    tela_base_dados(df)
elif pagina == "Validações":
    tela_validacoes(df)
elif pagina in ["Demandas de Auditoria", "Relatórios", "Histórico", "Configurações"]:
    st.title(pagina)
    st.info("Esta área está reservada para uma próxima etapa. Não há dados complementares reais disponíveis nesta versão.")
