from datetime import date
import pandas as pd
import streamlit as st
import plotly.express as px
from modules.exportacao import gerar_excel

def tela_dashboard(df):
    st.title("Dashboard")
    st.caption("Indicadores calculados exclusivamente a partir das planilhas carregadas.")
    c1,c2,c3 = st.columns(3)
    c1.metric("Total de Operações", f"{len(df):,}".replace(",", "."))
    c2.metric("Sistema LZ", int((df["Sistema"] == "LZ").sum()))
    c3.metric("Sistema XZ", int((df["Sistema"] == "XZ").sum()))
    st.info("Protocolos, cartas e auditorias não existem nas bases fornecidas. Esses indicadores não serão simulados nesta versão.")
    a,b = st.columns(2)
    with a:
        fig = px.pie(df, names="Sistema", title="Distribuição por sistema", hole=.45)
        st.plotly_chart(fig, use_container_width=True)
    with b:
        fig = px.bar(df["Tipo do Ativo"].value_counts().rename_axis("Tipo").reset_index(name="Operações"),
                     x="Tipo", y="Operações", title="Operações por tipo de ativo")
        st.plotly_chart(fig, use_container_width=True)
    a,b = st.columns(2)
    with a:
        fig = px.pie(df, names="Status", title="Distribuição por status")
        st.plotly_chart(fig, use_container_width=True)
    with b:
        por_carteira = df["Carteira"].value_counts().head(10).rename_axis("Carteira").reset_index(name="Operações")
        fig = px.bar(por_carteira, x="Operações", y="Carteira", orientation="h", title="10 maiores carteiras")
        st.plotly_chart(fig, use_container_width=True)

def tela_pendencias(df):
    st.title("Painel de Pendências")
    hoje = pd.Timestamp(date.today())
    base = df.copy()
    base["Dias até o vencimento"] = (base["Data de Vencimento"] - hoje).dt.days
    prazo = st.selectbox("Período", ["Vencidas", "Próximos 30 dias", "Próximos 60 dias", "Próximos 90 dias", "Todas"])
    carteira = st.selectbox("Carteira", ["Todas"] + sorted(base["Carteira"].dropna().unique().tolist()))
    sistema = st.selectbox("Sistema", ["Todos", "LZ", "XZ"])
    if prazo == "Vencidas":
        base = base[base["Dias até o vencimento"] < 0]
    elif prazo != "Todas":
        dias = int(prazo.split()[1])
        base = base[base["Dias até o vencimento"].between(0, dias)]
    if carteira != "Todas":
        base = base[base["Carteira"] == carteira]
    if sistema != "Todos":
        base = base[base["Sistema"] == sistema]
    base = base.sort_values("Dias até o vencimento")
    st.metric("Operações no recorte", len(base))
    st.dataframe(base[["Operação","Carteira","Quantidade","Sistema","Tipo do Ativo",
                       "Data de Vencimento","Dias até o vencimento","Status"]],
                 use_container_width=True, hide_index=True)
    st.download_button("Exportar pendências", gerar_excel(base),
                       "rastro_pendencias.xlsx",
                       "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")

def tela_base_dados(df):
    st.title("Base de Dados")
    sistema = st.selectbox("Visualizar base", ["Ambas", "LZ", "XZ"])
    base = df if sistema == "Ambas" else df[df["Sistema"] == sistema]
    a,b,c = st.columns(3)
    a.metric("Registros", len(base))
    b.metric("Carteiras", base["Carteira"].nunique())
    c.metric("Operações", base["Operação"].nunique())
    st.dataframe(base, use_container_width=True, hide_index=True)
    st.download_button("Exportar base exibida", gerar_excel(base),
                       f"rastro_base_{sistema.lower()}.xlsx",
                       "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")
    st.caption("A aplicação lê os arquivos originais sem alterá-los.")
