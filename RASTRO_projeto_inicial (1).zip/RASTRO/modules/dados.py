from pathlib import Path
import pandas as pd
import streamlit as st

ROOT = Path(__file__).resolve().parents[1]
DATA_DIR = ROOT / "data"

COLUNAS = [
    "Carteira", "Operação", "Data de Aquisição", "Data de Vencimento",
    "Quantidade", "Status", "Lastro", "Tipo do Ativo", "Indicador",
    "PU Atual", "Emitente", "Sistema"
]

@st.cache_data
def _ler_excel(caminho: str) -> pd.DataFrame:
    return pd.read_excel(caminho, engine="openpyxl")

def carregar_bases():
    partes, avisos = [], []
    for nome, sistema in [("Base_RASTRO_LZ.xlsx", "LZ"), ("Base_RASTRO_XZ.xlsx", "XZ")]:
        caminho = DATA_DIR / nome
        if not caminho.exists():
            avisos.append(f"Arquivo não encontrado: {nome}.")
            continue
        try:
            base = _ler_excel(str(caminho)).copy()
            faltantes = [c for c in COLUNAS if c not in base.columns]
            if faltantes:
                avisos.append(f"{nome}: colunas ausentes: {', '.join(faltantes)}.")
                continue
            base = base[COLUNAS]
            base["Sistema"] = sistema
            for coluna in ["Data de Aquisição", "Data de Vencimento"]:
                base[coluna] = pd.to_datetime(base[coluna], errors="coerce")
            base["Quantidade"] = pd.to_numeric(base["Quantidade"], errors="coerce")
            base["PU Atual"] = pd.to_numeric(base["PU Atual"], errors="coerce")
            partes.append(base)
        except Exception as erro:
            avisos.append(f"Não foi possível ler {nome}: {erro}")
    if not partes:
        return pd.DataFrame(columns=COLUNAS), avisos
    return pd.concat(partes, ignore_index=True), avisos
