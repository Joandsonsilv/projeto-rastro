import streamlit as st
import pandas as pd
from modules.exportacao import gerar_excel, resumo_texto

def _opcoes(df, coluna):
    return sorted(df[coluna].dropna().astype(str).unique().tolist())

def _limpar_filtros():
    chaves = ["consulta_operacao", "consulta_carteira", "consulta_sistema",
              "consulta_quantidade", "consulta_aquisicao", "consulta_vencimento",
              "consulta_status", "consulta_lastro", "consulta_tipo",
              "consulta_indicador", "consulta_emitente", "consulta_pu_min",
              "consulta_pu_max"]
    for chave in chaves:
        st.session_state.pop(chave, None)

def tela_consulta(df):
    st.title("Consulta de operações")
    st.caption("Pesquise por um ou mais campos. Os filtros são combinados.")
    with st.container(border=True):
        c1, c2, c3 = st.columns(3)
        operacao = c1.text_input("Operação", placeholder="Ex.: LZ1234567", key="consulta_operacao")
        carteira = c2.text_input("Carteira", placeholder="Digite parte do nome", key="consulta_carteira")
        sistema = c3.selectbox("Sistema", ["Todos", "LZ", "XZ"], key="consulta_sistema")
        c4, c5, c6 = st.columns(3)
        quantidade = c4.number_input("Quantidade", min_value=0, step=1, value=0,
                                     help="Use 0 para não aplicar este filtro.", key="consulta_quantidade")
        aquisicao = c5.date_input("Data de Aquisição", value=None, key="consulta_aquisicao")
        vencimento = c6.date_input("Data de Vencimento", value=None, key="consulta_vencimento")
        with st.expander("Mais filtros"):
            a, b, c = st.columns(3)
            status = a.multiselect("Status", _opcoes(df, "Status"), key="consulta_status")
            lastro = b.text_input("Lastro", key="consulta_lastro")
            tipo = c.multiselect("Tipo do Ativo", _opcoes(df, "Tipo do Ativo"), key="consulta_tipo")
            d, e, f = st.columns(3)
            indicador = d.multiselect("Indicador", _opcoes(df, "Indicador"), key="consulta_indicador")
            emitente = e.text_input("Emitente", key="consulta_emitente")
            pu_min = f.number_input("PU Atual mínimo", min_value=0.0, value=0.0, step=100.0, key="consulta_pu_min")
            pu_max = st.number_input("PU Atual máximo (0 = sem limite)", min_value=0.0, value=0.0, step=100.0, key="consulta_pu_max")
        b1, b2 = st.columns([1, 5])
        pesquisar = b1.button("Pesquisar", type="primary", use_container_width=True)
        limpar = b2.button("Limpar filtros", use_container_width=True, on_click=_limpar_filtros)

    filtrado = df.copy()
    if operacao.strip():
        filtrado = filtrado[filtrado["Operação"].astype(str).str.contains(operacao.strip(), case=False, na=False)]
    if carteira.strip():
        filtrado = filtrado[filtrado["Carteira"].astype(str).str.contains(carteira.strip(), case=False, na=False)]
    if sistema != "Todos":
        filtrado = filtrado[filtrado["Sistema"] == sistema]
    if quantidade > 0:
        filtrado = filtrado[filtrado["Quantidade"] == quantidade]
    if aquisicao:
        filtrado = filtrado[filtrado["Data de Aquisição"].dt.date == aquisicao]
    if vencimento:
        filtrado = filtrado[filtrado["Data de Vencimento"].dt.date == vencimento]
    if status:
        filtrado = filtrado[filtrado["Status"].isin(status)]
    if lastro.strip():
        filtrado = filtrado[filtrado["Lastro"].astype(str).str.contains(lastro.strip(), na=False)]
    if tipo:
        filtrado = filtrado[filtrado["Tipo do Ativo"].isin(tipo)]
    if indicador:
        filtrado = filtrado[filtrado["Indicador"].isin(indicador)]
    if emitente.strip():
        filtrado = filtrado[filtrado["Emitente"].astype(str).str.contains(emitente.strip(), case=False, na=False)]
    if pu_min > 0:
        filtrado = filtrado[filtrado["PU Atual"] >= pu_min]
    if pu_max > 0:
        filtrado = filtrado[filtrado["PU Atual"] <= pu_max]

    if pesquisar:
        st.toast("Pesquisa atualizada.", icon="🔎")

    st.divider()
    st.subheader("Resultado da pesquisa")
    st.write(f"**{len(filtrado)}** registro(s) encontrado(s).")
    if filtrado.empty:
        st.error("Nenhuma operação localizada. Revise os filtros.")
        return

    st.success("Operação(ões) localizada(s).")
    exibicao = filtrado.copy()
    for col in ["Data de Aquisição", "Data de Vencimento"]:
        exibicao[col] = exibicao[col].dt.strftime("%d/%m/%Y")
    st.dataframe(exibicao, use_container_width=True, hide_index=True)

    x1, x2 = st.columns(2)
    x1.download_button("📥 Gerar Excel", data=gerar_excel(filtrado),
                       file_name="rastro_resultado.xlsx",
                       mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                       use_container_width=True)
    resumo = resumo_texto(filtrado)
    x2.text_area("Resumo para copiar", value=resumo, height=100,
                 help="Selecione o texto e copie. A cópia automática depende das permissões do navegador.")

    st.subheader("Detalhamento")
    escolha = st.selectbox("Selecione uma operação para ver os detalhes",
                           filtrado.index.tolist(),
                           format_func=lambda i: f'{filtrado.loc[i, "Operação"]} | {filtrado.loc[i, "Carteira"]} | {filtrado.loc[i, "Sistema"]}')
    registro = filtrado.loc[escolha]
    tab1, tab2, tab3, tab4 = st.tabs(["Detalhes da Operação", "Dados da Carta", "Histórico na Carteira", "Observações"])
    with tab1:
        detalhes = registro.to_frame("Valor")
        st.dataframe(detalhes, use_container_width=True)
    with tab2:
        st.info("Sem dados de cartas na base original. Área reservada para integração futura.")
    with tab3:
        st.info("A planilha atual não contém histórico de movimentações por carteira.")
    with tab4:
        st.info("Nenhuma observação operacional foi fornecida para esta operação.")
