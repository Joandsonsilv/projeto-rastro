import streamlit as st

def aplicar_estilo():
    st.markdown("""
    <style>
    .stApp { background: #f5f7fb; color: #17243a; }
    [data-testid="stSidebar"] { background: #102b4e; }
    [data-testid="stSidebar"] * { color: #ffffff !important; }
    .rastro-header { background: linear-gradient(110deg,#102b4e,#174a78); padding: 22px 26px;
        border-radius: 13px; color: white; margin-bottom: 22px; }
    .rastro-header h1 { color:white; margin:0; font-size:30px; letter-spacing:1px; }
    .rastro-header p { color:#dce8f5; margin:5px 0 0 0; }
    div[data-testid="stMetric"] { background:white; border:1px solid #e3e9f1;
        padding:14px 16px; border-radius:11px; }
    div.stButton > button { border-radius:8px; }
    </style>
    """, unsafe_allow_html=True)

def cabecalho():
    st.markdown("""
    <div class="rastro-header">
      <h1>RASTRO</h1>
      <p>Rastreamento de Ativos, Saldos, Termos e Registros Operacionais</p>
    </div>
    """, unsafe_allow_html=True)

def menu_lateral():
    st.sidebar.markdown("## RASTRO")
    st.sidebar.caption("NAVEGAÇÃO")
    paginas = [
        "Consulta", "Dashboard", "Painel de Pendências",
        "Demandas de Auditoria", "Relatórios", "Base de Dados",
        "Histórico", "Validações", "Configurações"
    ]
    return st.sidebar.radio("Menu", paginas, label_visibility="collapsed")
